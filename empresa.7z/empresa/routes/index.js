var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res) {
  global.db.listarEmpresas((error, docs) =>{
    if(error){console.log(error);}
    res.render('index', { title: "Listar Empresas", 
    docs : docs});
  })
});

router.get('/new', function(req, res, next) {
  res.render('new', { title: 'Novo Cadastro', 
  	dadosempresa : {"nome":"", "numero":"" }, action: '/new' });
});

router.post('/new', function(req, res){
    var nome = req.body.nome;
    var numero = parseInt(req.body.numero);
    global.db.cadastrarEmpresas({ nome, numero }, (error, resultado) => {
      if(error){ return console.log(error);}
      res.redirect('/');
    })
})

router.get('/edit/:id', function(req, res){
	var id = req.params.id;
	global.db.buscarEmpresaPorId(id, (error, docs) => {
		if(error) {return console.log(error); }
		res.render('new', {title: 'Edição de Empresas', dadosempresa: docs[0],
			action: '/edit/' + docs[0]._id});
	})
});

//Criando rota para o Update e Delete
router.post('/new', function(req, res){
  var nome = req.body.nome;
  var numero = parseInt(req.body.numero);
  global.db.cadastrarEmpresas({ nome, numero }, (error, resultado) => {
    if(error){ return console.log(error);}
    res.redirect('/');
  })
})


module.exports = router;
